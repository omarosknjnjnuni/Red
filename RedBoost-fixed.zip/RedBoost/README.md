<p align="center"><img src="logo.png" width="140"></p>

# RedBoost ⚡
Game performance suite for Android (Root + Shizuku). Inspired by RedMagic *Game Space*.

## Features
- **Animated UI**: opening splash animation, sliding tab transitions, staggered card reveal, bouncy buttons, animated gauges
- **Game Space**: game library with posters + real app icons, per-game mode (Standard/Performance/Battery), FPS cap, render scale, *Boost & Play*, dexopt
- **Auto Game Space** *(new)*: pin a game with ★ — opening it applies the Performance preset + game mode automatically, leaving it restores your previous tweaks (uses Usage Access; one tap to grant via Shizuku/Root)
- **Energy-Cube HUD overlay**: RAM / temp / battery / CPU MHz / refresh rate floating over the game
- **Presets**: Eco / Balanced / Performance / Extreme (applied in a single shell call, current preset is highlighted)
- **Shizuku (no root)**: fixed-performance mode, animations, Doze, Adaptive Battery, DND, hide heads-up banners, Wi-Fi low-latency, fast DNS, thermal override, touch timing, show touches
- **Root**: CPU governor & freq lock, GPU (Adreno/Mali) lock, schedtune/uclamp boost, I/O scheduler/read-ahead, swappiness, TCP, KSM, thermal engine, all cores online
- **RAM**: live gauges (RAM / battery / temp), quick/deep clean, force-stop, cache clearing
- **Screen**: refresh-rate lock (+ on-screen Hz overlay), resolution scale, HWUI renderer (Skia GL/Vulkan), MSAA, HW overlays
- **Tools**: battery card (level/temp/voltage/current), live per-core CPU bars, ping test, storage TRIM, gyro/accelerometer + drift test, touch-node scanner, console

> The old screen *colour tuning* feature (saturation/contrast/warmth) was removed.

## Game posters
Popular games get their own colour poster automatically. For official artwork, drop an image into
`app/src/main/res/drawable/` named `poster_<package name with dots → underscores, lowercase>`, e.g.
`poster_com_tencent_ig.jpg` for PUBG Mobile. It is picked up automatically.

## Build
Push to GitHub → **Actions → Build APK** → download artifact `RedBoost-debug-apk`.
Or open in Android Studio (JDK 17) and press Run. Optional: `gradle wrapper --gradle-version 8.7`.

## Use
1. Install [Shizuku](https://shizuku.rikka.app/) and start it (Wireless debugging), or use a rooted phone.
2. Open RedBoost → Home → grant access.

> Kernel-node features differ per device. Extreme preset / thermal tweaks can overheat the phone. Use at your own risk.
