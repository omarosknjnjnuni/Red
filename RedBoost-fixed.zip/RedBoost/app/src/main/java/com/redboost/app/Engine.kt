package com.redboost.app

import android.app.ActivityManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Display
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.app.ServiceCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.File
import java.util.Locale

object Engine {
    var status by mutableStateOf("Ready")
    var output by mutableStateOf<String?>(null)
    val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    // Presets / restore never run at the same time (Auto Game Space can fire while the user taps).
    private val lock = Mutex()

    suspend fun execNow(label: String, cmd: String, root: Boolean, show: Boolean = false): String {
        if (!Sh.canRun(root)) {
            status = "✖ $label — needs ${if (root) "ROOT" else "Shizuku or Root"}"
            return ""
        }
        status = "… $label"
        val r = withContext(Dispatchers.IO) { Sh.run(cmd, root) }
        if (show) output = r.ifBlank { "(empty)" }
        status = if (r.startsWith("ERR")) "✖ $label: $r" else "✔ $label"
        return r
    }

    fun exec(label: String, cmd: String, root: Boolean, show: Boolean = false) {
        scope.launch { execNow(label, cmd, root, show) }
    }

    fun toggle(t: Tweak, enable: Boolean) {
        Store.set(t.id, enable)
        Store.savePreset("")
        exec(t.title, if (enable) t.on else (t.off ?: t.on), t.root)
    }

    private suspend fun runScript(s: String, root: Boolean) {
        if (s.isNotBlank()) withContext(Dispatchers.IO) { Sh.run(s, root) }
    }

    /** Applies a preset with ONE shell call per access level (much faster than one call per tweak). */
    suspend fun presetNow(name: String) {
        val ids = PRESETS[name] ?: return
        lock.withLock {
            status = "… Applying $name"
            val plain = StringBuilder()
            val rooted = StringBuilder()
            for (t in TOGGLES) {
                if (!t.preset || Build.VERSION.SDK_INT < t.minSdk || !Sh.canRun(t.root)) continue
                val en = t.id in ids
                val cmd = if (en) t.on else t.off
                if (t.off != null) Store.set(t.id, en)
                if (cmd == null) continue          // one-shot action that has nothing to undo
                (if (t.root) rooted else plain).append(cmd).append('\n')
            }
            runScript(plain.toString(), false)
            runScript(rooted.toString(), true)
            Store.savePreset(name)
            status = "✔ Preset $name applied"
        }
    }

    fun preset(name: String) { scope.launch { presetNow(name) } }

    fun snapshot(): Map<String, Boolean> = HashMap(Store.on)

    /** Puts the toggles back to what they were before an automatic Game Space session. */
    suspend fun restore(m: Map<String, Boolean>) {
        lock.withLock {
            val plain = StringBuilder()
            val rooted = StringBuilder()
            for (t in TOGGLES) {
                val off = t.off ?: continue
                if (!t.preset || Build.VERSION.SDK_INT < t.minSdk || !Sh.canRun(t.root)) continue
                val en = m[t.id] == true
                if ((Store.on[t.id] == true) == en) continue
                Store.set(t.id, en)
                (if (t.root) rooted else plain).append(if (en) t.on else off).append('\n')
            }
            runScript(plain.toString(), false)
            runScript(rooted.toString(), true)
            Store.savePreset("")
        }
    }

    fun boostAndPlay(ctx: Context, pkg: String, cfg: GameCfg) {
        scope.launch {
            status = "⚡ Boosting…"
            presetNow("Performance")
            execNow("RAM clean", "am kill-all; pm trim-caches 999999999999; true", false)
            execNow("Game mode", gameModeCmd(pkg, cfg), false)
            val launch = ctx.packageManager.getLaunchIntentForPackage(pkg)
            if (launch != null) {
                launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                ctx.startActivity(launch)
            }
            status = "✔ Boost done — good game!"
        }
    }
}

// ---------- system stats ----------
data class Stats(val ram: Int = 0, val temp: Float = 0f, val batt: Int = 0, val hz: Int = 0)
data class Batt(val level: Int, val temp: Float, val mv: Int, val charging: Boolean, val ma: Int)
data class Core(val cur: Int, val max: Int)

fun ramInfo(ctx: Context): Triple<Float, Long, Long> {
    val mi = ActivityManager.MemoryInfo()
    ctx.getSystemService(ActivityManager::class.java)?.getMemoryInfo(mi)
    val total = if (mi.totalMem > 0) mi.totalMem else 1L
    return Triple(1f - mi.availMem.toFloat() / total, mi.availMem shr 20, total shr 20)
}

fun battery(ctx: Context): Batt {
    val i = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
    val st = i?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
    val charging = st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL
    val bm = ctx.getSystemService(BatteryManager::class.java)
    val cur = runCatching { bm?.getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW) ?: 0 }.getOrDefault(0)
    val a = kotlin.math.abs(cur)
    val ma = if (a > 20000) a / 1000 else a      // some devices report mA, most report µA
    return Batt(
        level = i?.getIntExtra("level", 0) ?: 0,
        temp = (i?.getIntExtra("temperature", 0) ?: 0) / 10f,
        mv = i?.getIntExtra("voltage", 0) ?: 0,
        charging = charging, ma = ma
    )
}

fun displayHz(ctx: Context): Int {
    val dm = ctx.getSystemService(DisplayManager::class.java)
    return dm?.getDisplay(Display.DEFAULT_DISPLAY)?.refreshRate?.toInt() ?: 0
}

fun readStats(ctx: Context): Stats {
    val (used, _, _) = ramInfo(ctx)
    val b = battery(ctx)
    return Stats((used * 100).toInt(), b.temp, b.level, displayHz(ctx))
}

/** Reads per-core frequencies from sysfs. -1 means the node is not readable on this device. */
fun cpuCores(): List<Core> {
    val out = ArrayList<Core>()
    for (i in 0 until 16) {
        val dir = File("/sys/devices/system/cpu/cpu$i")
        if (!dir.exists()) break
        fun rd(n: String): Int =
            runCatching { (File(dir, "cpufreq/$n").readText().trim().toLong() / 1000).toInt() }.getOrDefault(-1)
        out.add(Core(rd("scaling_cur_freq"), rd("cpuinfo_max_freq")))
    }
    return out
}

fun hud(ctx: Context): String {
    val s = readStats(ctx)
    val top = cpuCores().maxOfOrNull { it.cur } ?: -1
    val mhz = if (top > 0) "$top MHz" else "— MHz"
    return "RAM ${s.ram}% | ${"%.1f".format(Locale.US, s.temp)}°C | ${s.batt}% | $mhz | ${s.hz}Hz"
}

// ---------- foreground-service helpers ----------
fun fgNotification(ctx: Context, text: String): Notification {
    ctx.getSystemService(NotificationManager::class.java)
        ?.createNotificationChannel(NotificationChannel("rb", "RedBoost", NotificationManager.IMPORTANCE_LOW))
    val pi = PendingIntent.getActivity(ctx, 0, Intent(ctx, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
    return Notification.Builder(ctx, "rb")
        .setContentTitle("RedBoost").setContentText(text)
        .setSmallIcon(R.drawable.ic_fg).setContentIntent(pi).setOngoing(true).build()
}

fun startFg(s: Service, id: Int, n: Notification) {
    ServiceCompat.startForeground(
        s, id, n,
        if (Build.VERSION.SDK_INT >= 34) ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE else 0
    )
}

// ---------- Energy-Cube style HUD overlay ----------
class OverlayService : Service() {
    private var tv: TextView? = null
    private val h = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() { tv?.text = hud(this@OverlayService); h.postDelayed(this, 1000) }
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        startFg(this, 1, fgNotification(this, "HUD overlay running"))
        if (tv == null) {
            if (!Settings.canDrawOverlays(this)) { stopSelf(); return START_NOT_STICKY }
            val d = resources.displayMetrics.density
            val v = TextView(this).apply {
                setTextColor(0xFFFF1744.toInt())
                background = GradientDrawable().apply { setColor(0xB3000000.toInt()); cornerRadius = 14f * d }
                textSize = 11f
                setPadding((12 * d).toInt(), (5 * d).toInt(), (12 * d).toInt(), (5 * d).toInt())
            }
            val lp = WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
                PixelFormat.TRANSLUCENT
            ).apply { gravity = Gravity.TOP or Gravity.END; x = (8 * d).toInt(); y = (24 * d).toInt() }
            getSystemService(WindowManager::class.java)?.addView(v, lp)
            tv = v
        }
        h.removeCallbacks(tick); h.post(tick)
        return START_STICKY
    }

    override fun onDestroy() {
        h.removeCallbacks(tick)
        tv?.let { v -> runCatching { getSystemService(WindowManager::class.java)?.removeView(v) } }
        tv = null
        super.onDestroy()
    }
}
