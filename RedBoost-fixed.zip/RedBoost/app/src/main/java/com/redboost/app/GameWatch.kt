package com.redboost.app

import android.app.Service
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Intent
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import kotlinx.coroutines.launch

/**
 * Auto Game Space: when a pinned (★) game comes to the foreground the chosen preset + game mode are applied,
 * and your previous tweak state is restored when you leave it. Needs Usage Access.
 */
class GameWatchService : Service() {
    private val h = Handler(Looper.getMainLooper())
    private var active: String? = null
    private var saved: Map<String, Boolean>? = null

    private val tick = object : Runnable {
        override fun run() { runCatching { poll() }; h.postDelayed(this, 2500) }
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        startFg(this, 2, fgNotification(this, "Auto Game Space is watching your pinned games"))
        h.removeCallbacks(tick); h.post(tick)
        return START_STICKY
    }

    @Suppress("DEPRECATION")
    private fun foregroundPkg(): String? {
        val usm = getSystemService(UsageStatsManager::class.java) ?: return null
        val now = System.currentTimeMillis()
        val ev = usm.queryEvents(now - 20_000, now) ?: return null
        val e = UsageEvents.Event()
        var last: String? = null
        while (ev.hasNextEvent()) {
            ev.getNextEvent(e)
            if (e.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND) last = e.packageName
        }
        return last
    }

    private fun ignore(p: String) =
        p == packageName || p == "com.android.systemui" || p.contains("inputmethod") || p.contains("keyboard")

    private fun poll() {
        val fg = foregroundPkg() ?: return
        if (fg == active) return
        if (fg in Store.favSet) enter(fg)
        else if (active != null && !ignore(fg)) leave()
    }

    private fun enter(pkg: String) {
        if (active == null) saved = Engine.snapshot()
        active = pkg
        Engine.scope.launch {
            Engine.presetNow(Store.sp.getString("auto_preset", "Performance") ?: "Performance")
            Engine.execNow("Game mode", gameModeCmd(pkg, Store.game(pkg)), false)
            Engine.status = "🎮 Game Space active"
        }
    }

    private fun leave() {
        active = null
        val s = saved
        saved = null
        if (s != null) Engine.scope.launch {
            Engine.restore(s)
            Engine.status = "↩ Settings restored"
        }
    }

    override fun onDestroy() {
        h.removeCallbacks(tick)
        super.onDestroy()
    }
}
