package com.redboost.app

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.net.Uri
import android.provider.Settings as AndroidSettings
import android.widget.Toast
import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.animateIntAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku

// ---------------- installed apps ----------------
data class AppItem(val pkg: String, val label: String, val game: Boolean)

@Suppress("DEPRECATION")
fun loadApps(ctx: Context): List<AppItem> {
    val pm = ctx.packageManager
    val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    return pm.queryIntentActivities(i, 0).map {
        val ai = it.activityInfo.applicationInfo
        AppItem(ai.packageName, it.loadLabel(pm).toString(),
            ai.category == ApplicationInfo.CATEGORY_GAME || (ai.flags and ApplicationInfo.FLAG_IS_GAME) != 0)
    }.distinctBy { it.pkg }.sortedWith(compareByDescending<AppItem> { it.game }.thenBy { it.label.lowercase() })
}

@Suppress("DEPRECATION")
fun serviceRunning(ctx: Context, cls: Class<*>): Boolean =
    (ctx.getSystemService(ActivityManager::class.java)?.getRunningServices(Int.MAX_VALUE) ?: emptyList())
        .any { it.service.className == cls.name }

// ---------------- posters ----------------
class Known(val name: String, val c1: Long, val c2: Long)

/**
 * Popular games get their own colour scheme. Want official artwork? Drop an image into res/drawable named
 * poster_<package with dots replaced by underscores>, e.g. poster_com_tencent_ig.jpg — it is picked up automatically.
 */
val KNOWN: Map<String, Known> = mapOf(
    "com.tencent.ig" to Known("PUBG MOBILE", 0xFFF2A900, 0xFF2A1B00),
    "com.pubg.imobile" to Known("BGMI", 0xFFFF8F00, 0xFF2A1400),
    "com.pubg.krmobile" to Known("PUBG MOBILE KR", 0xFFF2A900, 0xFF2A1B00),
    "com.vng.pubgmobile" to Known("PUBG MOBILE VN", 0xFFF2A900, 0xFF2A1B00),
    "com.activision.callofduty.shooter" to Known("Call of Duty: Mobile", 0xFF4CAF50, 0xFF0C1F0D),
    "com.garena.game.codm" to Known("Call of Duty: Mobile", 0xFF4CAF50, 0xFF0C1F0D),
    "com.dts.freefireth" to Known("Free Fire", 0xFFFF6D00, 0xFF3A1200),
    "com.dts.freefiremax" to Known("Free Fire MAX", 0xFFFF3D00, 0xFF2D0A00),
    "com.miHoYo.GenshinImpact" to Known("Genshin Impact", 0xFF5C6BC0, 0xFF101533),
    "com.miHoYo.Yuanshen" to Known("Genshin Impact", 0xFF5C6BC0, 0xFF101533),
    "com.HoYoverse.hkrpgoversea" to Known("Honkai: Star Rail", 0xFF7E57C2, 0xFF1A1033),
    "com.mobile.legends" to Known("Mobile Legends", 0xFF1E88E5, 0xFF08203A),
    "com.levelinfinite.sgameGlobal" to Known("Honor of Kings", 0xFFFFB300, 0xFF3A2400),
    "com.supercell.clashofclans" to Known("Clash of Clans", 0xFFFFA000, 0xFF3A2400),
    "com.supercell.clashroyale" to Known("Clash Royale", 0xFF1E88E5, 0xFF0A1A3A),
    "com.supercell.brawlstars" to Known("Brawl Stars", 0xFFFFC107, 0xFF4A2A00),
    "com.mojang.minecraftpe" to Known("Minecraft", 0xFF43A047, 0xFF14260F),
    "com.roblox.client" to Known("Roblox", 0xFFE53935, 0xFF2A0B0A),
    "com.innersloth.spacemafia" to Known("Among Us", 0xFFD32F2F, 0xFF2A0A0A),
    "com.kiloo.subwaysurf" to Known("Subway Surfers", 0xFF00ACC1, 0xFF062A30),
    "com.king.candycrushsaga" to Known("Candy Crush Saga", 0xFFEC407A, 0xFF3A0F20),
    "com.ea.gp.fifamobile" to Known("EA SPORTS FC Mobile", 0xFF00C853, 0xFF062A14),
    "jp.konami.pesam" to Known("eFootball", 0xFF3949AB, 0xFF0D1233),
    "com.nianticlabs.pokemongo" to Known("Pokémon GO", 0xFFEF5350, 0xFF2A1010),
    "com.pokemon.unite" to Known("Pokémon UNITE", 0xFF29B6F6, 0xFF08283A),
    "com.gameloft.android.ANMP.GloftA9HM" to Known("Asphalt 9", 0xFF00B0FF, 0xFF081A3A)
)

@Composable
fun AppIcon(pkg: String, size: Dp, modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    val bmp = remember(pkg) {
        runCatching { ctx.packageManager.getApplicationIcon(pkg).toBitmap(128, 128).asImageBitmap() }.getOrNull()
    }
    if (bmp != null) Image(
        bitmap = bmp, contentDescription = null,
        modifier = modifier.size(size).clip(RoundedCornerShape(size / 4))
    )
}

@Composable
fun Poster(pkg: String, label: String, modifier: Modifier = Modifier, banner: Boolean = false) {
    val ctx = LocalContext.current
    val res = remember(pkg) {
        ctx.resources.getIdentifier("poster_" + pkg.replace('.', '_').lowercase(), "drawable", ctx.packageName)
    }
    val colors = remember(pkg) {
        val k = KNOWN[pkg]
        if (k != null) Pair(Color(k.c1), Color(k.c2))
        else {
            val hue = ((pkg.hashCode() and 0x7fffffff) % 360).toFloat()
            Pair(Color.hsv(hue, 0.65f, 0.80f), Color.hsv((hue + 40f) % 360f, 0.75f, 0.30f))
        }
    }
    Box(modifier) {
        if (res != 0) {
            Image(painterResource(res), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        } else {
            Box(Modifier.fillMaxSize().background(Brush.linearGradient(listOf(colors.first, colors.second))))
            Canvas(Modifier.fillMaxSize()) {
                drawCircle(Color.White.copy(alpha = 0.10f), radius = size.minDimension * 0.75f, center = Offset(size.width, 0f))
                drawCircle(Color.Black.copy(alpha = 0.18f), radius = size.minDimension * 0.6f, center = Offset(0f, size.height))
            }
            Text(
                label.take(1).uppercase(), color = Color.White.copy(alpha = 0.12f),
                fontSize = if (banner) 120.sp else 90.sp, fontWeight = FontWeight.Black,
                modifier = Modifier.align(Alignment.BottomEnd).padding(end = 6.dp)
            )
            if (banner) AppIcon(pkg, 72.dp, Modifier.align(Alignment.CenterEnd).padding(end = 22.dp))
            else AppIcon(pkg, 56.dp, Modifier.align(Alignment.TopCenter).padding(top = 20.dp))
        }
    }
}

@Composable
fun GameCard(a: AppItem, selected: Boolean, fav: Boolean, onClick: () -> Unit, onFav: () -> Unit) {
    val sc by animateFloatAsState(
        targetValue = if (selected) 1.04f else 1f,
        animationSpec = spring(dampingRatio = 0.55f, stiffness = 300f), label = "card"
    )
    val borderC by animateColorAsState(if (selected) Rd else Color.Transparent, tween(250), label = "cardborder")
    Box(
        Modifier.width(112.dp).height(150.dp).graphicsLayer { scaleX = sc; scaleY = sc }
            .clip(RoundedCornerShape(18.dp)).border(2.dp, borderC, RoundedCornerShape(18.dp))
            .clickable(onClick = onClick)
    ) {
        Poster(a.pkg, a.label, Modifier.fillMaxSize())
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(0.5f to Color.Transparent, 1f to Color(0xDD000000))))
        Text(
            KNOWN[a.pkg]?.name ?: a.label,
            modifier = Modifier.align(Alignment.BottomStart).padding(8.dp),
            color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold,
            maxLines = 2, overflow = TextOverflow.Ellipsis, lineHeight = 14.sp
        )
        Icon(
            Icons.Default.Star, null, tint = if (fav) Gold else Color(0x99FFFFFF),
            modifier = Modifier.align(Alignment.TopEnd).padding(4.dp).size(32.dp)
                .clip(CircleShape).clickable(onClick = onFav).padding(6.dp)
        )
    }
}

@Composable
fun AddCard(onClick: () -> Unit) {
    Column(
        Modifier.width(112.dp).height(150.dp).clip(RoundedCornerShape(18.dp))
            .background(Cd2).border(1.dp, Line, RoundedCornerShape(18.dp)).clickable(onClick = onClick),
        verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(Icons.Default.Add, null, tint = Rd, modifier = Modifier.size(34.dp))
        Spacer(Modifier.height(6.dp))
        Text("All apps", color = Gr, fontSize = 12.sp)
    }
}

@Composable
fun StatTile(label: String, value: String, modifier: Modifier = Modifier) {
    Column(
        modifier.clip(RoundedCornerShape(14.dp)).background(Color(0x40000000)).padding(vertical = 10.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(value, fontWeight = FontWeight.Black, fontSize = 17.sp, color = Color.White, maxLines = 1)
        Text(label, fontSize = 10.sp, color = Gr)
    }
}

// ---------------- HOME ----------------
@Composable
fun HomeScreen() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var pkg by remember { mutableStateOf(Store.sp.getString("last", null)) }
    var cfg by remember(pkg) { mutableStateOf(pkg?.let { Store.game(it) } ?: GameCfg()) }
    var showAll by remember { mutableStateOf(false) }
    var extreme by remember { mutableStateOf(false) }
    var overlay by remember { mutableStateOf(serviceRunning(ctx, OverlayService::class.java)) }
    var auto by remember { mutableStateOf(serviceRunning(ctx, GameWatchService::class.java)) }
    val apps by produceState(emptyList<AppItem>()) { value = withContext(Dispatchers.IO) { loadApps(ctx) } }
    val stats by produceState(Stats()) { while (true) { value = readStats(ctx); delay(2000) } }
    val ram by animateIntAsState(stats.ram, tween(600), label = "ram")
    val batt by animateIntAsState(stats.batt, tween(600), label = "batt")

    val library = remember(apps, Store.favSet) {
        val byPkg = apps.associateBy { it.pkg }
        val pinned = Store.favSet.mapNotNull { byPkg[it] }.sortedBy { it.label.lowercase() }
        val detected = apps.filter { it.game && it.pkg !in Store.favSet }
        (pinned + detected).take(16)
    }
    val cur = pkg
    val shown = if (cur != null && library.none { it.pkg == cur }) apps.filter { it.pkg == cur }.take(1) + library else library
    val label = remember(pkg, apps) {
        pkg?.let { p -> apps.firstOrNull { it.pkg == p }?.label ?: p } ?: "No game selected"
    }

    val askUsage = {
        ctx.startActivity(Intent(AndroidSettings.ACTION_USAGE_ACCESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        Toast.makeText(ctx, "Allow RedBoost, come back and switch Auto Game Space on again", Toast.LENGTH_LONG).show()
    }
    val startWatch = {
        ctx.startForegroundService(Intent(ctx, GameWatchService::class.java))
        auto = true
    }

    Page {
        // ----- hero -----
        Revealed {
            Card(
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = Color.Transparent),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    Modifier.background(Brush.linearGradient(listOf(Color(0xFF4A0F1C), Cd, Color(0xFF0D2A33)))).padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    val inf = rememberInfiniteTransition(label = "float")
                    val dy by inf.animateFloat(
                        initialValue = -6f, targetValue = 6f,
                        animationSpec = infiniteRepeatable(tween(1800, easing = FastOutSlowInEasing), RepeatMode.Reverse),
                        label = "dy"
                    )
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                        Image(painterResource(R.drawable.ic_logo), null, Modifier.size(68.dp).graphicsLayer { translationY = dy })
                        Column {
                            Text("RedBoost", fontSize = 28.sp, fontWeight = FontWeight.Black, color = Color.White)
                            Text("Game performance suite", color = Gr, fontSize = 12.sp)
                        }
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        StatTile("RAM", "$ram%", Modifier.weight(1f))
                        StatTile("TEMP", "${"%.1f".format(java.util.Locale.US, stats.temp)}°", Modifier.weight(1f))
                        StatTile("BATTERY", "$batt%", Modifier.weight(1f))
                        StatTile("REFRESH", "${stats.hz}Hz", Modifier.weight(1f))
                    }
                }
            }
        }

        // ----- access -----
        Box2("Access", Icons.Default.Lock) {
            Text("Root: " + if (Sh.hasRoot) "✔ available" else "✖ not detected", fontSize = 13.sp)
            Text(
                "Shizuku: " + when {
                    Sh.shizuku -> "✔ granted"
                    Sh.shizukuAlive -> "running — permission needed"
                    else -> "✖ not running"
                }, fontSize = 13.sp
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                RbButton(onClick = { scope.launch { Sh.detectRoot(); Sh.refreshShizuku() } }, outlined = true) { Text("Re-check") }
                RbButton(onClick = {
                    if (Sh.shizukuAlive && !Sh.shizuku) runCatching { Shizuku.requestPermission(100) }
                    else {
                        val li = ctx.packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api")
                        if (li != null) ctx.startActivity(li)
                        else Toast.makeText(ctx, "Install Shizuku first", Toast.LENGTH_LONG).show()
                    }
                }, outlined = true) { Text(if (Sh.shizukuAlive && !Sh.shizuku) "Grant Shizuku" else "Open Shizuku") }
            }
        }

        // ----- presets -----
        Box2("Presets", Icons.Default.Settings) {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("Eco", "Balanced", "Performance", "Extreme").forEach { n ->
                    Pill(n, Store.preset == n, modifier = Modifier.weight(1f), hPad = 2.dp, textSize = 11.sp) {
                        if (n == "Extreme") extreme = true else Engine.preset(n)
                    }
                }
            }
            Crossfade(targetState = Store.preset, animationSpec = tween(250), label = "presetinfo") { p ->
                Text(PRESET_INFO[p] ?: "Custom — you changed tweaks manually.", fontSize = 11.sp, color = Gr)
            }
        }

        // ----- game space -----
        Box2("Game Space", Icons.Default.PlayArrow) {
            Text("Tap a game to select it  •  ★ pins it for Auto Game Space", fontSize = 11.sp, color = Gr)
            LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(vertical = 4.dp)) {
                items(shown, key = { it.pkg }) { a ->
                    GameCard(
                        a, selected = a.pkg == pkg, fav = a.pkg in Store.favSet,
                        onClick = { pkg = a.pkg; Store.sp.edit().putString("last", a.pkg).apply() },
                        onFav = { Store.setFav(a.pkg, a.pkg !in Store.favSet) }
                    )
                }
                item { AddCard { showAll = true } }
            }
            val p = pkg
            if (p == null) {
                Text("No game selected yet.", fontSize = 12.sp, color = Gr)
            } else {
                fun save(c: GameCfg) { cfg = c; Store.saveGame(p, c) }
                Box(Modifier.fillMaxWidth().height(110.dp).clip(RoundedCornerShape(16.dp))) {
                    Poster(p, label, Modifier.fillMaxSize(), banner = true)
                    Box(Modifier.fillMaxSize().background(Brush.horizontalGradient(0f to Color(0xCC000000), 0.7f to Color.Transparent)))
                    Column(Modifier.align(Alignment.CenterStart).padding(16.dp)) {
                        Text(KNOWN[p]?.name ?: label, color = Color.White, fontWeight = FontWeight.Black, fontSize = 18.sp, maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.width(190.dp))
                        Text(if (p in Store.favSet) "★ pinned for Auto Game Space" else "Selected game", color = Color(0xCCFFFFFF), fontSize = 11.sp)
                    }
                }
                Text("Game mode", fontSize = 12.sp, color = Gr)
                Chips(listOf("Standard" to 1, "Performance" to 2, "Battery" to 3), cfg.mode) { save(cfg.copy(mode = it)) }
                Text("FPS cap (Android 13+)", fontSize = 12.sp, color = Gr)
                Chips(listOf("Default" to 0, "30" to 30, "60" to 60, "90" to 90, "120" to 120), cfg.fps) { save(cfg.copy(fps = it)) }
                Text("Render scale", fontSize = 12.sp, color = Gr)
                Chips(listOf("100%" to 100, "90%" to 90, "80%" to 80, "70%" to 70, "60%" to 60), cfg.scale) { save(cfg.copy(scale = it)) }

                val inf = rememberInfiniteTransition(label = "boost")
                val glow by inf.animateFloat(
                    initialValue = 0.25f, targetValue = 1f,
                    animationSpec = infiniteRepeatable(tween(900, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "glow"
                )
                Button(
                    onClick = { Engine.boostAndPlay(ctx, p, cfg) },
                    modifier = Modifier.fillMaxWidth().height(56.dp),
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(2.dp, Cy.copy(alpha = glow)),
                    colors = ButtonDefaults.buttonColors(containerColor = Rd)
                ) {
                    Text("⚡ BOOST & PLAY", fontWeight = FontWeight.Black, fontSize = 17.sp, letterSpacing = 1.sp)
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    RbButton(onClick = { Engine.exec("Game mode", gameModeCmd(p, cfg), false) }, outlined = true) { Text("Apply mode only") }
                    RbButton(onClick = { Engine.exec("Optimize (dexopt)", "cmd package compile -m speed -f $p", false, true) }, outlined = true) { Text("Optimize app") }
                }
            }
        }

        // ----- automation -----
        Box2("Automation", Icons.Default.Refresh) {
            SwitchRow(
                "Auto Game Space",
                "Opens a ★ pinned game → Performance preset + game mode are applied. Leaving it → your previous settings come back.",
                auto
            ) { v ->
                if (!v) {
                    ctx.stopService(Intent(ctx, GameWatchService::class.java)); auto = false
                } else if (Store.hasUsageAccess(ctx)) {
                    startWatch()
                } else if (Sh.canRun(false)) {
                    scope.launch {
                        Engine.execNow("Grant usage access", "appops set ${ctx.packageName} GET_USAGE_STATS allow", false)
                        delay(400)
                        if (Store.hasUsageAccess(ctx)) startWatch() else askUsage()
                    }
                } else askUsage()
            }
            if (auto && Store.favSet.isEmpty()) {
                Text("Pin at least one game with ★ so there is something to watch.", fontSize = 11.sp, color = Gold, modifier = Modifier.padding(horizontal = 8.dp))
            }
            SwitchRow("Energy-Cube HUD overlay", "RAM / temp / battery / CPU / Hz floating over your game", overlay) { v ->
                if (v && !AndroidSettings.canDrawOverlays(ctx)) {
                    ctx.startActivity(Intent(AndroidSettings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${ctx.packageName}")))
                    Toast.makeText(ctx, "Allow 'Display over other apps', come back and switch it on again", Toast.LENGTH_LONG).show()
                } else if (v) {
                    ctx.startForegroundService(Intent(ctx, OverlayService::class.java)); overlay = true
                } else {
                    ctx.stopService(Intent(ctx, OverlayService::class.java)); overlay = false
                }
            }
        }
    }

    if (showAll) {
        var q by remember { mutableStateOf("") }
        val list = remember(apps, q) { apps.filter { it.label.contains(q, ignoreCase = true) } }
        AlertDialog(
            onDismissRequest = { showAll = false }, containerColor = Cd,
            confirmButton = { TextButton(onClick = { showAll = false }) { Text("Close") } },
            title = { Text("Choose a game / app") },
            text = {
                Column {
                    OutlinedTextField(q, { q = it }, singleLine = true, label = { Text("Search") }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(8.dp))
                    LazyColumn(Modifier.heightIn(max = 380.dp)) {
                        items(list, key = { it.pkg }) { a ->
                            Row(
                                Modifier.fillMaxWidth().clickable {
                                    pkg = a.pkg; Store.sp.edit().putString("last", a.pkg).apply(); showAll = false
                                }.padding(vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                AppIcon(a.pkg, 36.dp)
                                Text((if (a.game) "🎮 " else "") + a.label, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Icon(
                                    Icons.Default.Star, null, tint = if (a.pkg in Store.favSet) Gold else Gr,
                                    modifier = Modifier.size(32.dp).clip(CircleShape)
                                        .clickable { Store.setFav(a.pkg, a.pkg !in Store.favSet) }.padding(5.dp)
                                )
                            }
                        }
                    }
                }
            }
        )
    }
    if (extreme) AlertDialog(
        onDismissRequest = { extreme = false }, containerColor = Cd,
        confirmButton = { TextButton(onClick = { extreme = false; Engine.preset("Extreme") }) { Text("Apply", color = Rd) } },
        dismissButton = { TextButton(onClick = { extreme = false }) { Text("Cancel") } },
        icon = { Icon(Icons.Default.Warning, null, tint = Rd) }, title = { Text("Extreme preset") },
        text = { Text("Locks CPU/GPU at max, disables thermal throttling and more. Phone will get HOT and drain fast. Use 'Eco' to restore afterwards.") }
    )
}
