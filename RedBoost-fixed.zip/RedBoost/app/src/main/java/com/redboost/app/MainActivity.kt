package com.redboost.app

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch
import rikka.shizuku.Shizuku

class MainActivity : ComponentActivity() {
    private val binderL = Shizuku.OnBinderReceivedListener { Sh.refreshShizuku() }
    private val deadL = Shizuku.OnBinderDeadListener { Sh.refreshShizuku() }
    private val permL = Shizuku.OnRequestPermissionResultListener { _, _ -> Sh.refreshShizuku() }

    // Needed on Android 13+ so the HUD / Auto Game Space notification can be shown.
    private val notifPerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Store.init(this)
        Shizuku.addBinderReceivedListenerSticky(binderL)
        Shizuku.addBinderDeadListener(deadL)
        Shizuku.addRequestPermissionResultListener(permL)
        Sh.refreshShizuku()
        lifecycleScope.launch { Sh.detectRoot() }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
        setContent { RedTheme { Root() } }
    }

    override fun onResume() { super.onResume(); Sh.refreshShizuku() }

    override fun onDestroy() {
        Shizuku.removeBinderReceivedListener(binderL)
        Shizuku.removeBinderDeadListener(deadL)
        Shizuku.removeRequestPermissionResultListener(permL)
        super.onDestroy()
    }
}
