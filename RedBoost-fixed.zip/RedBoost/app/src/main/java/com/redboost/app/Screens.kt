package com.redboost.app

import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.widget.Toast
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale

// ---------------- SHIZUKU ----------------
@Composable
fun ShizukuScreen() = Page {
    Box2("Performance (Shizuku / ADB level)", Icons.Default.Settings) {
        if (!Sh.canRun(false)) Text("Start Shizuku and grant permission (Home → Access).", color = Rd, fontSize = 12.sp)
        TOGGLES.filter { it.tab == "perf" }.forEach { TweakRow(it) }
    }
    Box2("Touch", Icons.Default.Star) { TOGGLES.filter { it.tab == "touch" }.forEach { TweakRow(it) } }
}

// ---------------- ROOT ----------------
@Composable
fun RootScreen() = Page {
    Box2("Root tweaks", Icons.Default.Lock) {
        if (!Sh.hasRoot) Text("Root not detected — these are locked.", color = Rd, fontSize = 12.sp)
        TOGGLES.filter { it.tab == "root" }.forEach { TweakRow(it) }
    }
    Box2("Governors & kernel", Icons.Default.Build) { CHOICES.filter { it.tab == "root" }.forEach { ChoiceRow(it) } }
    Box2("Info", Icons.Default.Info) { ActionRow(ACT_CPU) }
}

// ---------------- RAM ----------------
@Composable
fun Gauge(value: Float, label: String, shown: String, size: Dp = 104.dp, invert: Boolean = false) {
    val v by animateFloatAsState(value.coerceIn(0f, 1f), tween(700, easing = FastOutSlowInEasing), label = "gauge")
    val c = lerp(if (invert) Rd else Cy, if (invert) Cy else Rd, v)
    Box(Modifier.size(size), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize().padding(6.dp)) {
            val sw = 10.dp.toPx()
            val s = Size(this.size.width - sw, this.size.height - sw)
            val tl = Offset(sw / 2, sw / 2)
            drawArc(Color(0xFF2A2A36), 135f, 270f, false, tl, s, style = Stroke(sw, cap = StrokeCap.Round))
            drawArc(c, 135f, 270f * v, false, tl, s, style = Stroke(sw, cap = StrokeCap.Round))
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(shown, fontSize = 18.sp, fontWeight = FontWeight.Black, color = Color.White)
            Text(label, fontSize = 10.sp, color = Gr)
        }
    }
}

@Composable
fun RamScreen() {
    val ctx = LocalContext.current
    var used by remember { mutableStateOf(0f) }
    var info by remember { mutableStateOf("") }
    var batt by remember { mutableStateOf(Batt(0, 0f, 0, false, 0)) }
    LaunchedEffect(Unit) {
        while (true) {
            val (u, free, total) = ramInfo(ctx)
            batt = battery(ctx)
            used = u
            info = "free $free MB of $total MB"
            delay(1500)
        }
    }
    Page {
        Box2("Memory", Icons.Default.Delete) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                Gauge(used, "RAM", "${(used * 100).toInt()}%")
                Gauge(batt.level / 100f, "BATTERY", "${batt.level}%", invert = true)
                Gauge(batt.temp / 60f, "TEMP", "${"%.0f".format(Locale.US, batt.temp)}°")
            }
            Text(info, fontSize = 12.sp, color = Gr, modifier = Modifier.fillMaxWidth())
        }
        Box2("Clean", Icons.Default.Refresh) { RAM_ACTIONS.forEach { ActionRow(it) } }
        Box2("RedBoost cache", Icons.Default.Delete) {
            RbButton(onClick = { ctx.cacheDir.deleteRecursively(); Toast.makeText(ctx, "Cleared", Toast.LENGTH_SHORT).show() }) {
                Text("Clear own cache")
            }
        }
    }
}

// ---------------- SCREEN (refresh rate + graphics) ----------------
@Composable
fun ScreenTab() = Page {
    Box2("Display", Icons.Default.Star) {
        CHOICES.filter { it.id == "refresh" }.forEach { ChoiceRow(it) }
        TOGGLES.filter { it.id == "hzoverlay" }.forEach { TweakRow(it) }
    }
    Box2("Graphics", Icons.Default.Settings) {
        CHOICES.filter { it.id == "renderer" }.forEach { ChoiceRow(it) }
        TOGGLES.filter { it.tab == "screen" && it.id != "hzoverlay" }.forEach { TweakRow(it) }
        ResolutionRow()
        ActionRow(ACT_GPU)
    }
}

@Composable
fun ResolutionRow() {
    val scope = rememberCoroutineScope()
    var sel by remember { mutableStateOf(Store.sp.getInt("res", 100)) }
    val ok = Sh.canRun(false)
    Column(Modifier.padding(horizontal = 8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text("Render resolution", fontSize = 14.sp, fontWeight = FontWeight.Medium, color = if (ok) Color.White else Gr)
        Text("Lower resolution = more FPS. If the screen ever looks wrong, pick 100%.", fontSize = 11.sp, color = Gr)
        Chips(listOf("100%" to 100, "90%" to 90, "80%" to 80, "70%" to 70), sel, ok) { p ->
            sel = p
            Store.sp.edit().putInt("res", p).apply()
            scope.launch {
                if (p == 100) {
                    Engine.execNow("Resolution 100%", "wm size reset", false)
                } else {
                    val out = withContext(Dispatchers.IO) { Sh.run("wm size", false) }
                    val m = Regex("Physical size: (\\d+)x(\\d+)").find(out)
                    if (m == null) {
                        Engine.status = "✖ Couldn't read the physical screen size"
                    } else {
                        val w = m.groupValues[1].toInt() * p / 100 / 2 * 2
                        val h = m.groupValues[2].toInt() * p / 100 / 2 * 2
                        Engine.execNow("Resolution $p%", "wm size ${w}x$h", false)
                    }
                }
            }
        }
    }
}

// ---------------- TOOLS ----------------
@Composable
fun ToolsScreen() = Page {
    BatteryCard()
    CpuCard()
    Box2("Network & storage", Icons.Default.Notifications) {
        ActionRow(ACT_PING)
        ActionRow(ACT_TRIM)
    }
    Box2("Touch & sensors info", Icons.Default.Info) {
        ActionRow(ACT_TOUCH)
        ActionRow(ACT_SENSOR)
        ActionRow(ACT_BATT)
    }
    SensorsCard()
    ConsoleCard()
    Box2("About", Icons.Default.Info) {
        Text(
            "RedBoost 1.1 — Root + Shizuku game booster.\nFeatures needing kernel nodes (CPU/GPU, I/O, touch rate) vary per device. Use at your own risk.",
            fontSize = 12.sp, color = Gr
        )
    }
}

@Composable
fun BatteryCard() {
    val ctx = LocalContext.current
    var b by remember { mutableStateOf(battery(ctx)) }
    LaunchedEffect(Unit) { while (true) { b = battery(ctx); delay(2000) } }
    Box2("Battery", Icons.Default.Notifications) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            StatTile("LEVEL", "${b.level}%", Modifier.weight(1f))
            StatTile("TEMP", "${"%.1f".format(Locale.US, b.temp)}°C", Modifier.weight(1f))
            StatTile("VOLT", "${"%.2f".format(Locale.US, b.mv / 1000f)}V", Modifier.weight(1f))
            StatTile(if (b.charging) "CHARGING" else "DRAW", "${b.ma}mA", Modifier.weight(1f))
        }
    }
}

@Composable
fun CpuCard() {
    var cores by remember { mutableStateOf(cpuCores()) }
    LaunchedEffect(Unit) { while (true) { cores = cpuCores(); delay(1000) } }
    Box2("CPU cores (live)", Icons.Default.Settings) {
        if (cores.none { it.cur > 0 }) {
            Text("Per-core frequency isn't readable on this device — use “CPU / GPU / temps” in the Root tab.", fontSize = 11.sp, color = Gr)
        } else {
            Row(Modifier.fillMaxWidth().height(96.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                cores.forEachIndexed { i, c ->
                    val f = if (c.cur > 0 && c.max > 0) (c.cur.toFloat() / c.max).coerceIn(0f, 1f) else 0f
                    val h by animateFloatAsState(f, tween(500), label = "core$i")
                    Column(Modifier.weight(1f).fillMaxHeight(), horizontalAlignment = Alignment.CenterHorizontally) {
                        Box(Modifier.weight(1f).fillMaxWidth().clip(RoundedCornerShape(6.dp)).background(Cd2), contentAlignment = Alignment.BottomCenter) {
                            Box(Modifier.fillMaxWidth().fillMaxHeight(h).clip(RoundedCornerShape(6.dp)).background(lerp(Cy, Rd, h)))
                        }
                        Text(if (c.cur > 0) "${c.cur / 100 / 10f}" else "off", fontSize = 8.sp, color = Gr, maxLines = 1)
                    }
                }
            }
            Text("Bars = current / max frequency, labels in GHz", fontSize = 10.sp, color = Gr)
        }
    }
}

@Composable
fun SensorsCard() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var g by remember { mutableStateOf(FloatArray(3)) }
    var a by remember { mutableStateOf(FloatArray(3)) }
    var bias by remember { mutableStateOf<FloatArray?>(null) }
    var sampling by remember { mutableStateOf(false) }
    val acc = remember { FloatArray(4) }
    DisposableEffect(Unit) {
        val sm = ctx.getSystemService(SensorManager::class.java)
        val l = object : SensorEventListener {
            override fun onSensorChanged(e: SensorEvent) {
                if (e.sensor.type == Sensor.TYPE_GYROSCOPE) {
                    g = e.values.clone()
                    if (sampling) { for (i in 0..2) acc[i] += e.values[i]; acc[3]++ }
                } else a = e.values.clone()
            }
            override fun onAccuracyChanged(s: Sensor?, x: Int) {}
        }
        if (sm != null) {
            val gyro = sm.getDefaultSensor(Sensor.TYPE_GYROSCOPE)
            val accel = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
            if (gyro != null) sm.registerListener(l, gyro, SensorManager.SENSOR_DELAY_UI)
            if (accel != null) sm.registerListener(l, accel, SensorManager.SENSOR_DELAY_UI)
        }
        onDispose { sm?.unregisterListener(l) }
    }
    Box2("Gyro / Accelerometer", Icons.Default.Refresh) {
        Text("Gyro (rad/s): " + g.joinToString("  ") { "%.3f".format(Locale.US, it) }, fontFamily = FontFamily.Monospace, fontSize = 12.sp)
        Text("Accel (m/s²): " + a.joinToString("  ") { "%.2f".format(Locale.US, it) }, fontFamily = FontFamily.Monospace, fontSize = 12.sp)
        bias?.let { b ->
            val worst = b.maxOf { kotlin.math.abs(it) }
            Text(
                "Drift: " + b.joinToString("  ") { "%.4f".format(Locale.US, it) } +
                    if (worst > 0.02f) "  ⚠ high — recalibrate on a flat surface" else "  ✔ good",
                fontSize = 12.sp, color = Cy
            )
        }
        RbButton(onClick = {
            scope.launch {
                acc.fill(0f); sampling = true; delay(2000); sampling = false
                if (acc[3] > 0) bias = floatArrayOf(acc[0] / acc[3], acc[1] / acc[3], acc[2] / acc[3])
            }
        }) { Text("Measure drift (keep phone still)") }
    }
}

@Composable
fun ConsoleCard() {
    val scope = rememberCoroutineScope()
    var cmd by remember { mutableStateOf("") }
    var asRoot by remember { mutableStateOf(false) }
    var out by remember { mutableStateOf("") }
    Box2("Console", Icons.Default.Build) {
        OutlinedTextField(cmd, { cmd = it }, label = { Text("Command") }, modifier = Modifier.fillMaxWidth())
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            RbSwitch(asRoot) { asRoot = it }
            Text("root")
            RbButton(onClick = {
                scope.launch {
                    out = if (Sh.canRun(asRoot)) withContext(Dispatchers.IO) { Sh.run(cmd, asRoot) } else "ERR: no access"
                }
            }) { Text("Run") }
        }
        if (out.isNotEmpty()) Text(out, fontFamily = FontFamily.Monospace, fontSize = 11.sp)
    }
}
