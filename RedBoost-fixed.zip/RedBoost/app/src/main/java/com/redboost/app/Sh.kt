package com.redboost.app

import android.content.pm.PackageManager
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku
import java.util.concurrent.TimeUnit
import kotlin.concurrent.thread

/** Runs shell commands through Root (su) or Shizuku (ADB-level shell). */
object Sh {
    var hasRoot by mutableStateOf(false)
    var shizuku by mutableStateOf(false)       // alive + permission granted
    var shizukuAlive by mutableStateOf(false)

    fun canRun(needRoot: Boolean) = if (needRoot) hasRoot else (hasRoot || shizuku)

    fun refreshShizuku() {
        shizukuAlive = try { Shizuku.pingBinder() } catch (e: Throwable) { false }
        shizuku = try {
            shizukuAlive && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
        } catch (e: Throwable) { false }
    }

    /** Waits up to 15s so the user has time to accept the root-manager prompt. */
    suspend fun detectRoot() {
        hasRoot = withContext(Dispatchers.IO) {
            runCatching {
                val p = Runtime.getRuntime().exec(arrayOf("su", "-c", "id"))
                val out = StringBuffer()
                val reader = thread(isDaemon = true) { runCatching { out.append(p.inputStream.bufferedReader().readText()) } }
                if (!p.waitFor(15, TimeUnit.SECONDS)) {
                    p.destroy()
                    false
                } else {
                    reader.join(500)
                    out.toString().contains("uid=0")
                }
            }.getOrDefault(false)
        }
    }

    fun run(cmd: String, needRoot: Boolean = false): String = try {
        when {
            hasRoot -> collect(Runtime.getRuntime().exec(arrayOf("su", "-c", cmd)))
            shizuku && !needRoot -> collect(shizukuProc(cmd))
            else -> "ERR: no permission (Root/Shizuku required)"
        }
    } catch (e: Throwable) { "ERR: ${e.message}" }

    // Shizuku.newProcess is private in API 13+, so call it by reflection.
    private fun shizukuProc(cmd: String): Process {
        val m = Shizuku::class.java.getDeclaredMethod(
            "newProcess", Array<String>::class.java, Array<String>::class.java, String::class.java
        )
        m.isAccessible = true
        return m.invoke(null, arrayOf("sh", "-c", cmd), null, null) as Process
    }

    // stdout and stderr are drained in parallel so a full pipe buffer can never deadlock the process.
    private fun collect(p: Process): String {
        val err = StringBuffer()
        val t = thread(isDaemon = true) { runCatching { err.append(p.errorStream.bufferedReader().readText()) } }
        val o = p.inputStream.bufferedReader().readText()
        p.waitFor()
        t.join(1000)
        return (o + err.toString()).trim()
    }
}
