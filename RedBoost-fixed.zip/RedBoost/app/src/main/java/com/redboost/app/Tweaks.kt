package com.redboost.app

import android.app.AppOpsManager
import android.content.Context
import android.content.SharedPreferences
import android.os.Build
import android.os.Process
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.util.Locale

const val CPUF = "/sys/devices/system/cpu/cpu[0-9]*/cpufreq"

/**
 * tab: perf (Shizuku/ADB), touch, root, screen. root=true => needs su.
 * off==null => one-shot action (no switch). preset=false => presets never touch it.
 */
data class Tweak(
    val id: String, val tab: String, val title: String, val desc: String, val root: Boolean,
    val on: String, val off: String? = null, val risky: Boolean = false, val minSdk: Int = 0,
    val preset: Boolean = true
)

data class Choice(
    val id: String, val tab: String, val title: String, val desc: String, val root: Boolean,
    val options: List<Pair<String, String>>, val minSdk: Int = 0
)

data class Action(
    val title: String, val desc: String, val root: Boolean, val cmd: String,
    val show: Boolean = true, val danger: Boolean = false
)

private const val GPU_DEV = "for d in /sys/class/devfreq/*gpu* /sys/class/devfreq/*mali*; do if [ -d \$d ]; then "

val TOGGLES = listOf(
    // ---------- Shizuku / ADB level ----------
    Tweak("fixedperf", "perf", "Fixed performance mode", "Keeps the device at sustained max performance (Android 12+)", false,
        "cmd power set-fixed-performance-mode-enabled true", "cmd power set-fixed-performance-mode-enabled false", minSdk = 31),
    Tweak("anim0", "perf", "Disable animations", "Window/transition/animator scale = 0 for snappier system UI", false,
        "settings put global window_animation_scale 0; settings put global transition_animation_scale 0; settings put global animator_duration_scale 0",
        "settings put global window_animation_scale 1; settings put global transition_animation_scale 1; settings put global animator_duration_scale 1"),
    Tweak("doze", "perf", "Disable Doze", "Stops deep-sleep from killing background network", false,
        "dumpsys deviceidle disable", "dumpsys deviceidle enable"),
    Tweak("abatt", "perf", "Disable Adaptive Battery", "Prevents the system from restricting apps", false,
        "settings put global adaptive_battery_management_enabled 0", "settings put global adaptive_battery_management_enabled 1"),
    Tweak("standby", "perf", "Disable App Standby", "Apps keep full access to CPU/network", false,
        "settings put global app_standby_enabled 0", "settings put global app_standby_enabled 1"),
    Tweak("scanoff", "perf", "Stop background Wi-Fi/BLE scanning", "Less radio interference & wakeups", false,
        "settings put global wifi_scan_always_enabled 0; settings put global ble_scan_always_enabled 0",
        "settings put global wifi_scan_always_enabled 1; settings put global ble_scan_always_enabled 1"),
    Tweak("dnd", "perf", "Do Not Disturb (gaming)", "Priority-only notifications while playing", false,
        "cmd notification set_dnd priority", "cmd notification set_dnd off"),
    Tweak("headsup", "perf", "Hide heads-up banners", "No pop-up notification banners over the game", false,
        "settings put global heads_up_notifications_enabled 0", "settings put global heads_up_notifications_enabled 1"),
    Tweak("lowlat", "perf", "Wi-Fi low-latency mode", "Lower ping in online games (Android 11+)", false,
        "cmd wifi force-low-latency-mode enabled", "cmd wifi force-low-latency-mode disabled", minSdk = 30),
    Tweak("dns", "perf", "Fast DNS (Cloudflare)", "Private DNS → one.one.one.one for quicker lookups", false,
        "settings put global private_dns_mode hostname; settings put global private_dns_specifier one.one.one.one",
        "settings put global private_dns_mode opportunistic; settings delete global private_dns_specifier", preset = false),
    Tweak("stayon", "perf", "Keep screen on while charging", "Screen never sleeps on charger", false,
        "svc power stayon true", "svc power stayon false"),
    Tweak("autobright", "perf", "Disable auto-brightness", "Stable brightness during play", false,
        "settings put system screen_brightness_mode 0", "settings put system screen_brightness_mode 1"),
    Tweak("blur", "perf", "Disable window blur", "Saves GPU (Android 12+)", false,
        "settings put global disable_window_blurs 1", "settings put global disable_window_blurs 0", minSdk = 31),
    Tweak("thermal", "perf", "Thermal override (no throttling)", "Tells the system thermal status = none. Device may get VERY hot.", false,
        "cmd thermalservice override-status 0", "cmd thermalservice reset", risky = true, minSdk = 29),
    // ---------- Touch ----------
    Tweak("longpress", "touch", "Fast long-press (250ms)", "Faster long-press recognition", false,
        "settings put secure long_press_timeout 250", "settings put secure long_press_timeout 400"),
    Tweak("multipress", "touch", "Fast multi-press (200ms)", "Faster double-tap detection", false,
        "settings put secure multi_press_timeout 200", "settings put secure multi_press_timeout 300"),
    Tweak("pointer", "touch", "Max pointer speed", "Higher pointer/touch speed", false,
        "settings put system pointer_speed 7", "settings put system pointer_speed 0"),
    Tweak("showtouch", "touch", "Show touches", "Draws a dot under every finger (handy for testing touch response)", false,
        "settings put system show_touches 1", "settings put system show_touches 0", preset = false),
    // ---------- Screen / GFX ----------
    Tweak("hwoverlay", "screen", "Disable HW overlays", "Forces GPU composition (can help some games, uses more power)", false,
        "service call SurfaceFlinger 1008 i32 1", "service call SurfaceFlinger 1008 i32 0"),
    Tweak("msaa", "screen", "Force 4x MSAA", "Smoother edges in OpenGL ES 2.0 apps (device dependent)", false,
        "setprop debug.egl.force_msaa true", "setprop debug.egl.force_msaa false"),
    Tweak("hzoverlay", "screen", "Show refresh-rate overlay", "Live Hz counter drawn by the system (device dependent)", false,
        "service call SurfaceFlinger 1034 i32 1", "service call SurfaceFlinger 1034 i32 0", preset = false),
    // ---------- ROOT ----------
    Tweak("cpumax", "root", "Lock CPU at max frequency", "min = max on every core (heats up!)", true,
        "for c in $CPUF; do m=\$(cat \$c/cpuinfo_max_freq); chmod 644 \$c/scaling_min_freq \$c/scaling_max_freq; echo \$m > \$c/scaling_max_freq; echo \$m > \$c/scaling_min_freq; done",
        "for c in $CPUF; do chmod 644 \$c/scaling_min_freq; cat \$c/cpuinfo_min_freq > \$c/scaling_min_freq; done"),
    Tweak("gpumax", "root", "Lock GPU at max frequency", "Adreno (kgsl) & Mali/devfreq GPUs: governor=performance, min=max", true,
        "g=/sys/class/kgsl/kgsl-3d0; if [ -d \$g ]; then echo performance > \$g/devfreq/governor; cat \$g/devfreq/max_freq > \$g/devfreq/min_freq; echo 1 > \$g/force_clk_on; echo 1 > \$g/force_bus_on; echo 1 > \$g/force_rail_on; echo 0 > \$g/throttling; fi; " +
            GPU_DEV + "echo performance > \$d/governor; cat \$d/max_freq > \$d/min_freq; fi; done; true",
        "g=/sys/class/kgsl/kgsl-3d0; if [ -d \$g ]; then echo msm-adreno-tz > \$g/devfreq/governor; echo 0 > \$g/force_clk_on; echo 0 > \$g/force_bus_on; echo 0 > \$g/force_rail_on; echo 1 > \$g/throttling; n=\$(tr ' ' '\\n' < \$g/devfreq/available_frequencies | sort -n | head -1); echo \$n > \$g/devfreq/min_freq; fi; " +
            GPU_DEV + "echo simple_ondemand > \$d/governor; n=\$(tr ' ' '\\n' < \$d/available_frequencies | sort -n | head -1); echo \$n > \$d/min_freq; fi; done; true"),
    Tweak("allcores", "root", "Bring all CPU cores online", "Forces every core online (resets on reboot)", true,
        "for c in /sys/devices/system/cpu/cpu[0-9]*/online; do echo 1 > \$c; done; true"),
    Tweak("stune", "root", "Boost foreground (top-app) priority", "schedtune/uclamp boost for the app you're using", true,
        "[ -e /dev/stune/top-app/schedtune.boost ] && echo 30 > /dev/stune/top-app/schedtune.boost; [ -e /dev/stune/top-app/schedtune.prefer_idle ] && echo 1 > /dev/stune/top-app/schedtune.prefer_idle; [ -e /dev/cpuctl/top-app/cpu.uclamp.min ] && echo 20 > /dev/cpuctl/top-app/cpu.uclamp.min; true",
        "[ -e /dev/stune/top-app/schedtune.boost ] && echo 0 > /dev/stune/top-app/schedtune.boost; [ -e /dev/stune/top-app/schedtune.prefer_idle ] && echo 0 > /dev/stune/top-app/schedtune.prefer_idle; [ -e /dev/cpuctl/top-app/cpu.uclamp.min ] && echo 0 > /dev/cpuctl/top-app/cpu.uclamp.min; true"),
    Tweak("io", "root", "Storage I/O tuning", "read_ahead 1024KB, no entropy/iostats, no merges", true,
        "for q in /sys/block/*/queue; do echo 1024 > \$q/read_ahead_kb; echo 0 > \$q/add_random; echo 0 > \$q/iostats; echo 2 > \$q/nomerges; done; true",
        "for q in /sys/block/*/queue; do echo 128 > \$q/read_ahead_kb; echo 1 > \$q/add_random; echo 1 > \$q/iostats; echo 0 > \$q/nomerges; done; true"),
    Tweak("vm", "root", "Memory (VM) tuning", "swappiness 40, vfs_cache_pressure 50", true,
        "echo 40 > /proc/sys/vm/swappiness; echo 50 > /proc/sys/vm/vfs_cache_pressure",
        "echo 60 > /proc/sys/vm/swappiness; echo 100 > /proc/sys/vm/vfs_cache_pressure"),
    Tweak("ksm", "root", "Disable KSM", "Stops kernel page-merging (less background CPU use)", true,
        "echo 0 > /sys/kernel/mm/ksm/run; true", "echo 1 > /sys/kernel/mm/ksm/run; true"),
    Tweak("printk", "root", "Silence kernel logging", "printk off — a tiny CPU / I/O saving", true,
        "echo 0 0 0 0 > /proc/sys/kernel/printk", "echo 4 4 1 7 > /proc/sys/kernel/printk"),
    Tweak("thermaleng", "root", "Stop thermal engine", "Stops vendor thermal daemons. DANGEROUS: can overheat the phone.", true,
        "stop thermal-engine; stop thermald; stop vendor.thermal-engine; true",
        "start thermal-engine; start thermald; start vendor.thermal-engine; true", risky = true, preset = false)
)

private fun rr(hz: Int) =
    "settings put system min_refresh_rate $hz; settings put system peak_refresh_rate $hz; settings put system user_refresh_rate $hz"

val CHOICES = listOf(
    Choice("refresh", "screen", "Refresh rate", "Lock the display refresh rate", false, listOf(
        "Auto" to "settings delete system min_refresh_rate; settings delete system peak_refresh_rate; settings delete system user_refresh_rate",
        "60" to rr(60), "90" to rr(90), "120" to rr(120), "144" to rr(144), "165" to rr(165))),
    Choice("renderer", "screen", "HWUI renderer", "Affects apps launched afterwards (restart the game)", false, listOf(
        "Default" to "setprop debug.hwui.renderer ''",
        "Skia GL" to "setprop debug.hwui.renderer skiagl",
        "Skia Vulkan" to "setprop debug.hwui.renderer skiavk")),
    Choice("governor", "root", "CPU governor", "Applies to all cores", true,
        listOf("performance", "schedutil", "conservative", "powersave").map { g ->
            g to "for c in $CPUF; do chmod 644 \$c/scaling_governor; echo $g > \$c/scaling_governor; done" }),
    Choice("sched", "root", "I/O scheduler", "For sd*/mmcblk*/nvme* block devices", true,
        listOf("none", "mq-deadline", "kyber", "bfq").map { s ->
            s to "for q in /sys/block/sd*/queue /sys/block/mmcblk*/queue /sys/block/nvme*/queue; do echo $s > \$q/scheduler; done 2>/dev/null; true" }),
    Choice("swap", "root", "Swappiness", "Lower = keeps more apps in RAM, higher = more zRAM use", true,
        listOf("10", "30", "60", "100").map { v -> v to "echo $v > /proc/sys/vm/swappiness" }),
    Choice("tcp", "root", "TCP congestion control", "Network latency tuning", true,
        listOf("cubic", "bbr", "westwood").map { v -> v to "sysctl -w net.ipv4.tcp_congestion_control=$v" })
)

val PRESETS: Map<String, Set<String>> = run {
    val balanced = setOf("anim0", "lowlat", "scanoff", "blur")
    val perf = balanced + setOf("fixedperf", "dnd", "headsup", "abatt", "standby", "autobright", "longpress", "multipress", "stune", "io", "vm", "ksm", "printk")
    val extreme = perf + setOf("hwoverlay", "thermal", "doze", "cpumax", "gpumax", "allcores", "pointer")
    mapOf("Eco" to emptySet(), "Balanced" to balanced, "Performance" to perf, "Extreme" to extreme)
}

val PRESET_INFO = mapOf(
    "Eco" to "Restores every preset-controlled tweak to its default.",
    "Balanced" to "Light touch: no animations, low-latency Wi-Fi, no blur.",
    "Performance" to "Fixed performance, DND, I/O + VM tuning, faster touch.",
    "Extreme" to "Locks CPU/GPU at max & removes throttling. Gets HOT."
)

val RAM_ACTIONS = listOf(
    Action("Quick clean", "Kill cached background processes + trim app caches", false,
        "am kill-all; pm trim-caches 999999999999; true", false),
    Action("Force-stop all 3rd-party apps", "Stops every user app except RedBoost", false,
        "for p in \$(pm list packages -3 | cut -d: -f2); do [ \"\$p\" != \"com.redboost.app\" ] && am force-stop \$p; done; true", false, danger = true),
    Action("Deep clean (ROOT)", "sync + drop_caches + compact memory + kill background", true,
        "sync; echo 3 > /proc/sys/vm/drop_caches; echo 1 > /proc/sys/vm/compact_memory; am kill-all; true", false),
    Action("Clear ALL app caches (ROOT)", "Deletes cache folders of every app", true,
        "rm -rf /data/data/*/cache/* /sdcard/Android/data/*/cache/* 2>/dev/null; pm trim-caches 999999999999; true", false, danger = true)
)

val ACT_CPU = Action("CPU / GPU / temps", "Governors, frequencies, thermal zones", false,
    "for c in $CPUF; do echo \$c: \$(cat \$c/scaling_governor) \$(cat \$c/scaling_cur_freq)/\$(cat \$c/cpuinfo_max_freq); done; cat /sys/class/kgsl/kgsl-3d0/gpuclk /sys/class/kgsl/kgsl-3d0/devfreq/governor 2>/dev/null; for z in /sys/class/thermal/thermal_zone*; do echo \$(cat \$z/type) \$(cat \$z/temp); done | head -15")
val ACT_GPU = Action("GPU / Vulkan info", "Platform, GLES version, Vulkan", false,
    "getprop ro.board.platform; getprop ro.hardware.vulkan; getprop ro.opengles.version; dumpsys SurfaceFlinger | grep -i -E 'GLES|GL_|Vulkan' | head -8")
val ACT_TOUCH = Action("Touch node scan", "Find vendor touch / game-mode / sampling-rate nodes", false,
    "ls /proc/touchpanel /sys/class/touch 2>/dev/null; find /sys/devices/platform -maxdepth 6 \\( -iname '*sample*' -o -iname '*report_rate*' -o -iname '*game*' -o -iname '*touch_boost*' \\) 2>/dev/null | head -40")
val ACT_SENSOR = Action("Sensor info", "Gyro/accelerometer rates (sensorservice)", false,
    "dumpsys sensorservice | grep -i -E 'gyro|accel' | head -12")
val ACT_BATT = Action("Battery details", "Health, voltage, charger type (dumpsys battery)", false, "dumpsys battery")
val ACT_PING = Action("Ping test", "4 pings to 8.8.8.8 — check your latency", false, "ping -c 4 -W 2 8.8.8.8")
val ACT_TRIM = Action("Storage TRIM", "Runs fstrim — keeps storage speed up over time", false,
    "sm fstrim || sm idle-maint run; true")

// ---------------- per-game config & storage ----------------
data class GameCfg(val mode: Int = 2, val fps: Int = 0, val scale: Int = 100)

fun gameModeCmd(pkg: String, c: GameCfg): String {
    val f = if (c.fps > 0) " --fps ${c.fps}" else ""
    val d = if (c.scale < 100) " --downscale ${String.format(Locale.US, "%.2f", c.scale / 100f)}" else ""
    return "cmd game set --mode ${c.mode}$f$d $pkg || cmd game mode ${c.mode} $pkg"
}

object Store {
    lateinit var sp: SharedPreferences
    val on = mutableStateMapOf<String, Boolean>()
    val picked = mutableStateMapOf<String, String>()      // last chosen option per Choice
    var favSet by mutableStateOf<Set<String>>(emptySet())  // pinned games (Auto Game Space)
    var preset by mutableStateOf("")

    fun init(c: Context) {
        sp = c.getSharedPreferences("rb", 0)
        for ((k, v) in sp.all) {
            if (k.startsWith("t_") && v is Boolean) on[k.removePrefix("t_")] = v
            if (k.startsWith("c_") && v is String) picked[k.removePrefix("c_")] = v
        }
        favSet = (sp.getStringSet("favs", emptySet()) ?: emptySet()).toSet()
        preset = sp.getString("preset", "") ?: ""
    }

    fun set(id: String, v: Boolean) { on[id] = v; sp.edit().putBoolean("t_$id", v).apply() }
    fun pick(id: String, v: String) { picked[id] = v; sp.edit().putString("c_$id", v).apply() }
    fun savePreset(n: String) { preset = n; sp.edit().putString("preset", n).apply() }

    fun setFav(pkg: String, v: Boolean) {
        val s = favSet.toMutableSet()
        if (v) s.add(pkg) else s.remove(pkg)
        favSet = s
        sp.edit().putStringSet("favs", HashSet(s)).apply()
    }

    fun game(pkg: String): GameCfg {
        val p = sp.getString("g_$pkg", null)?.split(",")?.mapNotNull { it.toIntOrNull() }
        return if (p != null && p.size == 3) GameCfg(p[0], p[1], p[2]) else GameCfg()
    }
    fun saveGame(pkg: String, c: GameCfg) { sp.edit().putString("g_$pkg", "${c.mode},${c.fps},${c.scale}").apply() }

    @Suppress("DEPRECATION")
    fun hasUsageAccess(c: Context): Boolean {
        val ops = c.getSystemService(AppOpsManager::class.java) ?: return false
        val mode = if (Build.VERSION.SDK_INT >= 29)
            ops.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), c.packageName)
        else
            ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), c.packageName)
        return mode == AppOpsManager.MODE_ALLOWED
    }
}
