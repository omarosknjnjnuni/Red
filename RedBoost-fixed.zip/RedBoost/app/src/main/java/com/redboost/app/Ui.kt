package com.redboost.app

import android.os.Build
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

val Rd = Color(0xFFFF1744)
val Cy = Color(0xFF00E5FF)
val Bk = Color(0xFF0B0B10)
val Cd = Color(0xFF16161F)
val Cd2 = Color(0xFF212130)
val Gr = Color(0xFF9A9AA8)
val Dk = Color(0xFF3A0D16)
val Gold = Color(0xFFFFC107)
val Green = Color(0xFF00E676)
val Line = Color(0x1FFFFFFF)

@Composable
fun RedTheme(content: @Composable () -> Unit) = MaterialTheme(
    colorScheme = darkColorScheme(
        primary = Rd, secondary = Cy, background = Bk, surface = Cd, surfaceVariant = Cd2,
        onBackground = Color.White, onSurface = Color.White, onPrimary = Color.White,
        secondaryContainer = Dk, onSecondaryContainer = Color.White
    ),
    content = content
)

// =====================================================================================
//  Opening animation + root
// =====================================================================================
@Composable
fun Root() {
    var splash by rememberSaveable { mutableStateOf(true) }
    Crossfade(targetState = splash, animationSpec = tween(450), label = "root") { s ->
        if (s) Splash { splash = false } else App()
    }
}

@Composable
fun Splash(onDone: () -> Unit) {
    val scale = remember { Animatable(0.3f) }
    val fade = remember { Animatable(0f) }
    val textFade = remember { Animatable(0f) }
    val inf = rememberInfiniteTransition(label = "splash")
    val rot by inf.animateFloat(
        initialValue = 0f, targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(2200, easing = LinearEasing)), label = "rot"
    )
    val pulse by inf.animateFloat(
        initialValue = 0.94f, targetValue = 1.06f,
        animationSpec = infiniteRepeatable(tween(900, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "pulse"
    )
    LaunchedEffect(Unit) {
        launch { fade.animateTo(1f, tween(500)) }
        launch { scale.animateTo(1f, spring(dampingRatio = 0.45f, stiffness = 180f)) }
        delay(500)
        textFade.animateTo(1f, tween(500))
        delay(650)
        onDone()
    }
    Box(
        Modifier.fillMaxSize().background(Brush.radialGradient(listOf(Color(0xFF2B0A13), Bk))),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(Modifier.size(200.dp), contentAlignment = Alignment.Center) {
                Canvas(Modifier.fillMaxSize().graphicsLayer { rotationZ = rot; alpha = fade.value }) {
                    val sw = 5.dp.toPx()
                    drawArc(
                        Brush.sweepGradient(listOf(Color.Transparent, Rd, Cy, Color.Transparent)),
                        0f, 360f, false,
                        Offset(sw, sw), Size(size.width - 2 * sw, size.height - 2 * sw),
                        style = Stroke(sw, cap = StrokeCap.Round)
                    )
                }
                Image(
                    painterResource(R.drawable.ic_logo), null,
                    Modifier.size(110.dp).graphicsLayer {
                        scaleX = scale.value * pulse; scaleY = scale.value * pulse; alpha = fade.value
                    }
                )
            }
            Spacer(Modifier.height(20.dp))
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.graphicsLayer { alpha = textFade.value; translationY = (1f - textFade.value) * 28f }
            ) {
                Text("REDBOOST", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Black, letterSpacing = 8.sp)
                Text("GAME PERFORMANCE SUITE", color = Gr, fontSize = 11.sp, letterSpacing = 3.sp)
            }
        }
    }
}

// =====================================================================================
//  App shell: header, animated tab transitions, bottom navigation
// =====================================================================================
@Composable
fun App() {
    var tab by rememberSaveable { mutableStateOf(0) }
    val tabs: List<Pair<String, ImageVector>> = listOf(
        "Home" to Icons.Default.Home, "Shizuku" to Icons.Default.Settings, "Root" to Icons.Default.Lock,
        "RAM" to Icons.Default.Delete, "Screen" to Icons.Default.Star, "Tools" to Icons.Default.Build
    )
    Scaffold(
        containerColor = Bk, contentColor = Color.White,
        topBar = { TopHeader() },
        bottomBar = {
            Column {
                Crossfade(
                    targetState = Engine.status, modifier = Modifier.fillMaxWidth().background(Cd),
                    animationSpec = tween(200), label = "status"
                ) { s ->
                    Text(
                        s, fontSize = 11.sp, color = if (s.startsWith("✖")) Rd else Cy,
                        maxLines = 2, overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 6.dp)
                    )
                }
                NavigationBar(containerColor = Cd, contentColor = Color.White) {
                    tabs.forEachIndexed { i, (label, icon) ->
                        NavigationBarItem(
                            selected = tab == i, onClick = { tab = i },
                            icon = {
                                val s by animateFloatAsState(
                                    targetValue = if (tab == i) 1.2f else 1f,
                                    animationSpec = spring(dampingRatio = 0.5f, stiffness = 400f), label = "tabicon"
                                )
                                Icon(icon, contentDescription = label, modifier = Modifier.graphicsLayer { scaleX = s; scaleY = s })
                            },
                            label = { Text(label, fontSize = 10.sp, maxLines = 1) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Rd, selectedTextColor = Rd, indicatorColor = Dk,
                                unselectedIconColor = Gr, unselectedTextColor = Gr
                            )
                        )
                    }
                }
            }
        }
    ) { pad ->
        AnimatedContent(
            targetState = tab,
            modifier = Modifier.padding(pad).fillMaxSize(),
            transitionSpec = {
                val dir = if (targetState > initialState) 1 else -1
                (fadeIn(tween(260)) + slideInHorizontally(tween(300)) { dir * it / 5 }) togetherWith
                    (fadeOut(tween(160)) + slideOutHorizontally(tween(260)) { -dir * it / 5 })
            },
            label = "tabs"
        ) { t ->
            when (t) {
                0 -> HomeScreen()
                1 -> ShizukuScreen()
                2 -> RootScreen()
                3 -> RamScreen()
                4 -> ScreenTab()
                else -> ToolsScreen()
            }
        }
    }
    Engine.output?.let {
        AlertDialog(
            onDismissRequest = { Engine.output = null },
            containerColor = Cd,
            confirmButton = { TextButton(onClick = { Engine.output = null }) { Text("OK") } },
            title = { Text("Output") },
            text = { Text(it, fontFamily = FontFamily.Monospace, fontSize = 11.sp, modifier = Modifier.verticalScroll(rememberScrollState())) }
        )
    }
}

@Composable
fun TopHeader() {
    Row(
        Modifier.fillMaxWidth().background(Bk).padding(horizontal = 14.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Image(painterResource(R.drawable.ic_logo), null, Modifier.size(34.dp))
        Spacer(Modifier.width(8.dp))
        Text("RedBoost", color = Color.White, fontWeight = FontWeight.Black, fontSize = 20.sp)
        Spacer(Modifier.weight(1f))
        AccessBadge("ROOT", Sh.hasRoot)
        Spacer(Modifier.width(6.dp))
        AccessBadge("SHIZUKU", Sh.shizuku)
    }
}

@Composable
fun AccessBadge(text: String, on: Boolean) {
    val c by animateColorAsState(if (on) Green else Gr, tween(300), label = "badge")
    Row(
        Modifier.clip(RoundedCornerShape(50)).background(c.copy(alpha = 0.14f)).padding(horizontal = 10.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(7.dp).clip(CircleShape).background(c))
        Spacer(Modifier.width(5.dp))
        Text(text, color = c, fontSize = 10.sp, fontWeight = FontWeight.Bold)
    }
}

// =====================================================================================
//  Shared components
// =====================================================================================
/** Every Page owns a counter so its cards slide in one after another. */
val LocalReveal = compositionLocalOf { intArrayOf(0) }

@Composable
fun Page(content: @Composable ColumnScope.() -> Unit) {
    val counter = remember { intArrayOf(0) }
    CompositionLocalProvider(LocalReveal provides counter) {
        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 14.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp), content = content
        )
    }
}

@Composable
fun Revealed(content: @Composable () -> Unit) {
    val counter = LocalReveal.current
    val idx = remember { counter[0]++ }
    val p = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        delay(idx * 70L)
        p.animateTo(1f, tween(450, easing = FastOutSlowInEasing))
    }
    Box(Modifier.graphicsLayer { alpha = p.value; translationY = (1f - p.value) * 60f }) { content() }
}

@Composable
fun Box2(title: String, icon: ImageVector? = null, content: @Composable ColumnScope.() -> Unit) {
    Revealed {
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = Cd, contentColor = Color.White),
            border = BorderStroke(1.dp, Brush.linearGradient(listOf(Color(0x55FF1744), Line, Color(0x3300E5FF)))),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (icon != null) {
                        Icon(icon, null, tint = Rd, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(8.dp))
                    }
                    Text(title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                }
                content()
            }
        }
    }
}

@Composable
fun RbButton(
    onClick: () -> Unit, modifier: Modifier = Modifier, enabled: Boolean = true, outlined: Boolean = false,
    content: @Composable RowScope.() -> Unit
) {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val sc by animateFloatAsState(
        targetValue = if (pressed) 0.93f else 1f,
        animationSpec = spring(dampingRatio = 0.5f, stiffness = 500f), label = "btn"
    )
    val m = modifier.graphicsLayer { scaleX = sc; scaleY = sc }
    val pad = PaddingValues(horizontal = 16.dp, vertical = 8.dp)
    val shape = RoundedCornerShape(12.dp)
    if (outlined) OutlinedButton(
        onClick = onClick, modifier = m, enabled = enabled, interactionSource = src,
        contentPadding = pad, shape = shape, content = content
    ) else Button(
        onClick = onClick, modifier = m, enabled = enabled, interactionSource = src,
        contentPadding = pad, shape = shape, content = content
    )
}

@Composable
fun Pill(
    text: String, selected: Boolean, enabled: Boolean = true, modifier: Modifier = Modifier,
    hPad: Dp = 14.dp, textSize: TextUnit = 13.sp, onClick: () -> Unit
) {
    val bg by animateColorAsState(if (selected) Rd else Cd2, tween(220), label = "pillbg")
    val fg by animateColorAsState(
        if (selected) Color.White else if (enabled) Color(0xFFD0D0DA) else Gr, tween(220), label = "pillfg"
    )
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val sc by animateFloatAsState(
        targetValue = if (pressed) 0.92f else 1f,
        animationSpec = spring(dampingRatio = 0.5f, stiffness = 500f), label = "pillsc"
    )
    Box(
        modifier.graphicsLayer { scaleX = sc; scaleY = sc }
            .clip(RoundedCornerShape(50)).background(bg)
            .border(1.dp, if (selected) Rd else Line, RoundedCornerShape(50))
            .clickable(interactionSource = src, indication = null, enabled = enabled, onClick = onClick)
            .padding(horizontal = hPad, vertical = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = fg, fontSize = textSize, fontWeight = FontWeight.Medium, maxLines = 1)
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun Chips(opts: List<Pair<String, Int>>, sel: Int, enabled: Boolean = true, on: (Int) -> Unit) {
    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        opts.forEach { (l, v) -> Pill(l, v == sel, enabled) { on(v) } }
    }
}

@Composable
fun Tag(text: String, c: Color) = Text(
    text, color = c, fontSize = 9.sp, fontWeight = FontWeight.Bold,
    modifier = Modifier.padding(start = 6.dp).clip(RoundedCornerShape(6.dp))
        .background(c.copy(alpha = 0.15f)).padding(horizontal = 5.dp, vertical = 1.dp)
)

@Composable
fun RbSwitch(checked: Boolean, enabled: Boolean = true, onChange: (Boolean) -> Unit) = Switch(
    checked = checked, onCheckedChange = onChange, enabled = enabled,
    colors = SwitchDefaults.colors(
        checkedThumbColor = Color.White, checkedTrackColor = Rd,
        uncheckedThumbColor = Gr, uncheckedTrackColor = Cd2, uncheckedBorderColor = Line
    )
)

@Composable
fun SwitchRow(title: String, desc: String, checked: Boolean, enabled: Boolean = true, onChange: (Boolean) -> Unit) {
    val bg by animateColorAsState(if (checked) Color(0x1FFF1744) else Color.Transparent, tween(250), label = "swbg")
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(bg).padding(horizontal = 8.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, fontSize = 14.sp, fontWeight = FontWeight.Medium, color = if (enabled) Color.White else Gr)
            Text(desc, fontSize = 11.sp, color = Gr)
        }
        RbSwitch(checked, enabled, onChange)
    }
}

@Composable
fun TweakRow(t: Tweak) {
    if (Build.VERSION.SDK_INT < t.minSdk) return
    val ok = Sh.canRun(t.root)
    var confirm by remember { mutableStateOf(false) }
    val isOn = Store.on[t.id] == true
    val bg by animateColorAsState(
        if (isOn && t.off != null) Color(0x1FFF1744) else Color.Transparent, tween(250), label = "rowbg"
    )
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(bg).padding(horizontal = 8.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(t.title, color = if (ok) Color.White else Gr, fontSize = 14.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f, fill = false))
                if (t.root) Tag("ROOT", Rd)
                if (t.risky) Tag("RISKY", Gold)
            }
            Text(t.desc, fontSize = 11.sp, color = Gr)
        }
        if (t.off != null) {
            RbSwitch(isOn, ok) { v -> if (v && t.risky) confirm = true else Engine.toggle(t, v) }
        } else {
            RbButton(onClick = { Engine.exec(t.title, t.on, t.root) }, enabled = ok) { Text("Run") }
        }
    }
    if (confirm) AlertDialog(
        onDismissRequest = { confirm = false }, containerColor = Cd,
        confirmButton = { TextButton(onClick = { confirm = false; Engine.toggle(t, true) }) { Text("Enable anyway", color = Rd) } },
        dismissButton = { TextButton(onClick = { confirm = false }) { Text("Cancel") } },
        icon = { Icon(Icons.Default.Warning, null, tint = Rd) },
        title = { Text("Warning") },
        text = { Text("${t.title}\n\nThis can overheat the device or damage the battery. Use at your own risk and watch the temperature.") }
    )
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ChoiceRow(c: Choice) {
    if (Build.VERSION.SDK_INT < c.minSdk) return
    val ok = Sh.canRun(c.root)
    Column(Modifier.padding(horizontal = 8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(c.title, color = if (ok) Color.White else Gr, fontSize = 14.sp, fontWeight = FontWeight.Medium)
            if (c.root) Tag("ROOT", Rd)
        }
        Text(c.desc, fontSize = 11.sp, color = Gr)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            c.options.forEach { (label, cmd) ->
                Pill(label, Store.picked[c.id] == label, ok) {
                    Store.pick(c.id, label)
                    Engine.exec("${c.title}: $label", cmd, c.root)
                }
            }
        }
    }
}

@Composable
fun ActionRow(a: Action) {
    val ok = Sh.canRun(a.root)
    var confirm by remember { mutableStateOf(false) }
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 2.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(a.title, color = if (ok) Color.White else Gr, fontSize = 14.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f, fill = false))
                if (a.root) Tag("ROOT", Rd)
            }
            Text(a.desc, fontSize = 11.sp, color = Gr)
        }
        RbButton(onClick = { if (a.danger) confirm = true else Engine.exec(a.title, a.cmd, a.root, a.show) }, enabled = ok) { Text("Run") }
    }
    if (confirm) AlertDialog(
        onDismissRequest = { confirm = false }, containerColor = Cd,
        confirmButton = { TextButton(onClick = { confirm = false; Engine.exec(a.title, a.cmd, a.root, a.show) }) { Text("Run anyway", color = Rd) } },
        dismissButton = { TextButton(onClick = { confirm = false }) { Text("Cancel") } },
        icon = { Icon(Icons.Default.Warning, null, tint = Rd) },
        title = { Text(a.title) },
        text = { Text("${a.desc}\n\nThis can close apps or delete data (you may lose unsaved progress). Continue?") }
    )
}
